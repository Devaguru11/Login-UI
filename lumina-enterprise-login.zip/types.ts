export interface ValidationErrors {
  name?: string;
  email?: string;
  password?: string;
  general?: string;
}

export interface UserCredentials {
  name?: string;
  email: string;
  password?: string;
}

export type InputType = 'text' | 'email' | 'password';
