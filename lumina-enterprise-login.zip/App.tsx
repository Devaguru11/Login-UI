import React from 'react';
import LoginForm from './components/LoginForm';
import ThemeToggle from './components/ThemeToggle';

function App() {
  return (
    <div className="flex min-h-full flex-row transition-colors duration-300">
      {/* Left Side - Visual / Marketing (Hidden on mobile) */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-slate-900 overflow-hidden">
        {/* Modern Abstract Background - Liquid Oil / 3D */}
        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-950/80 via-purple-950/60 to-slate-900/40 z-10" />
        <img
          src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"
          alt="Abstract Background"
          className="absolute inset-0 w-full h-full object-cover opacity-90"
        />
        
        {/* Decorative Elements - Glowing Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/30 rounded-full mix-blend-screen filter blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-1/3 right-1/4 w-64 h-64 bg-purple-500/30 rounded-full mix-blend-screen filter blur-[80px] animate-pulse animation-delay-2000"></div>
        
        <div className="relative z-20 flex flex-col justify-between w-full p-12 text-white h-full">
          {/* Logo Area */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl flex items-center justify-center shadow-2xl">
               <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                 <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
               </svg>
            </div>
            <span className="text-xl font-bold tracking-wide text-white drop-shadow-md">Lumina Enterprise</span>
          </div>

          {/* Testimonial / Hero Text */}
          <div className="space-y-8 max-w-lg mb-20">
            <div className="space-y-4">
               <h2 className="text-4xl lg:text-5xl font-bold leading-tight drop-shadow-lg">
                The workspace for the <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-purple-200">next generation</span>.
               </h2>
               <p className="text-lg text-indigo-100/90 leading-relaxed font-light drop-shadow-sm">
                 Join thousands of enterprise teams who use Lumina to drive innovation and streamline workflows securely.
               </p>
            </div>
            
            {/* Glassmorphism Card */}
            <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/10 shadow-xl transition-transform hover:scale-105 duration-300">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                  alt="User avatar" 
                  className="w-12 h-12 rounded-full border-2 border-indigo-300/50"
                />
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 border-2 border-indigo-900 rounded-full"></div>
              </div>
              <div>
                <div className="font-semibold text-white">David Chen</div>
                <div className="text-indigo-200 text-sm">VP of Engineering</div>
              </div>
              <div className="ml-auto">
                 <div className="flex text-yellow-400">
                   {[1,2,3,4,5].map(i => (
                     <svg key={i} className="w-4 h-4 fill-current drop-shadow" viewBox="0 0 20 20">
                       <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                     </svg>
                   ))}
                 </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-end text-xs text-indigo-200/60 font-medium tracking-wider uppercase">
            <div>© 2024 Lumina Inc.</div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="flex-1 flex flex-col justify-center min-h-screen relative 
        bg-slate-50 dark:bg-slate-950 
        px-4 sm:px-6 lg:px-20 xl:px-24
        transition-colors duration-300"
      >
        
        {/* Mobile Logo */}
        <div className="absolute top-0 left-0 p-6 lg:hidden z-50">
           <div className="flex items-center gap-2">
             <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                   <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                </svg>
             </div>
             <span className="font-bold text-slate-900 dark:text-white text-lg">Lumina</span>
           </div>
        </div>

        {/* Theme Toggle */}
        <div className="absolute top-0 right-0 p-6 z-50">
          <ThemeToggle />
        </div>

        <div className="w-full max-w-sm mx-auto lg:mx-0 relative z-10">
          <LoginForm />
        </div>
        
        {/* Subtle Background Pattern/Gradient for Right Side */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
             {/* Gradient Blob */}
             <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-indigo-500/5 dark:bg-indigo-500/10 blur-[120px]"></div>
             <div className="absolute bottom-[0%] left-[0%] w-[40%] h-[40%] rounded-full bg-purple-500/5 dark:bg-purple-500/10 blur-[100px]"></div>
        </div>
      </div>
    </div>
  );
}

export default App;