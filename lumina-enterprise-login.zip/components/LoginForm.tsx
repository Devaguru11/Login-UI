import React, { useState } from 'react';
import Input from './ui/Input';
import Button from './ui/Button';
import { 
  MailIcon, 
  LockIcon, 
  EyeIcon, 
  EyeOffIcon, 
  GoogleIcon, 
  GitHubIcon, 
  CheckCircleIcon,
  AlertCircleIcon,
  UserIcon,
  ArrowLeftIcon
} from './icons';
import { ValidationErrors, UserCredentials } from '../types';
import { authService } from '../services/auth';

type AuthMode = 'signin' | 'signup' | 'forgot';

const LoginForm: React.FC = () => {
  const [mode, setMode] = useState<AuthMode>('signin');
  const [formData, setFormData] = useState<UserCredentials>({ email: '', password: '', name: '' });
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const validate = (): boolean => {
    const newErrors: ValidationErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (mode === 'signup' && !formData.name) {
      newErrors.name = 'Full name is required';
    }

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (mode !== 'forgot') {
      if (!formData.password) {
        newErrors.password = 'Password is required';
      } else if (formData.password.length < 8) {
        newErrors.password = 'Password must be at least 8 characters';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setIsSuccess(false);

    if (!validate()) return;

    setIsLoading(true);

    try {
      if (mode === 'signin') {
        await authService.login(formData);
        setSuccessMessage('You have successfully logged in.');
        setIsSuccess(true);
      } else if (mode === 'signup') {
        await authService.signup(formData);
        setSuccessMessage('Account created successfully! You are now logged in.');
        setIsSuccess(true);
      } else if (mode === 'forgot') {
        await authService.forgotPassword(formData.email);
        setSuccessMessage(`If an account exists for ${formData.email}, you will receive a reset link shortly.`);
        setIsSuccess(true);
      }
    } catch (err: any) {
      setErrors({ general: err.message || 'Something went wrong. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = async (provider: 'google' | 'github') => {
    setIsLoading(true);
    setErrors({});
    try {
      await authService.socialLogin(provider);
      setSuccessMessage(`Successfully authenticated with ${provider === 'google' ? 'Google' : 'GitHub'}.`);
      setIsSuccess(true);
    } catch (err: any) {
      setErrors({ general: `Failed to login with ${provider}` });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear specific error
    if (errors[name as keyof ValidationErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
    // Clear general error
    if (errors.general) {
      setErrors(prev => ({ ...prev, general: undefined }));
    }
  };

  const switchMode = (newMode: AuthMode) => {
    setMode(newMode);
    setErrors({});
    setIsSuccess(false);
    setFormData({ email: '', password: '', name: '' });
  };

  if (isSuccess) {
    return (
      <div className="text-center py-10 animate-fade-in">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 mb-6">
          <CheckCircleIcon className="w-8 h-8" />
        </div>
        <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
          {mode === 'forgot' ? 'Check your email' : 'Welcome!'}
        </h3>
        <p className="text-slate-600 dark:text-slate-400 mb-8">{successMessage}</p>
        
        {mode === 'forgot' ? (
           <Button onClick={() => switchMode('signin')} variant="outline">
             Back to Sign in
           </Button>
        ) : (
          <Button onClick={() => {
            authService.logout();
            setIsSuccess(false);
            setFormData({ email: '', password: '', name: '' });
          }} variant="outline">
            Sign out
          </Button>
        )}
      </div>
    );
  }

  // Define headings and subtitles based on mode
  const getHeaderContent = () => {
    switch (mode) {
      case 'signup':
        return {
          title: 'Create an account',
          subtitle: 'Start your 30-day free trial. No credit card required.'
        };
      case 'forgot':
        return {
          title: 'Reset password',
          subtitle: 'Enter your email and we’ll send you instructions to reset your password.'
        };
      default:
        return {
          title: 'Sign in to your account',
          subtitle: 'Welcome back! Please enter your details.'
        };
    }
  };

  const header = getHeaderContent();

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="space-y-2 text-center lg:text-left">
        {mode === 'forgot' && (
           <button 
             onClick={() => switchMode('signin')}
             className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 mb-4 transition-colors lg:hidden mx-auto"
           >
             <ArrowLeftIcon className="w-4 h-4" /> Back to Login
           </button>
        )}
        
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
          {header.title}
        </h1>
        <p className="text-slate-600 dark:text-slate-400 text-sm">
          {header.subtitle}
        </p>
      </div>

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-5" noValidate>
        {/* Global Error Alert */}
        {errors.general && (
          <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 flex items-start gap-3 text-sm text-red-600 dark:text-red-400 animate-shake">
            <AlertCircleIcon className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{errors.general}</span>
          </div>
        )}

        {/* Name Field (Signup only) */}
        {mode === 'signup' && (
          <Input
            label="Full Name"
            id="name"
            name="name"
            type="text"
            placeholder="e.g. Sarah Jenkins"
            value={formData.name}
            onChange={handleChange}
            error={errors.name}
            icon={<UserIcon className="w-5 h-5" />}
            autoComplete="name"
            disabled={isLoading}
          />
        )}

        {/* Email Field (All modes) */}
        <Input
          label="Email"
          id="email"
          name="email"
          type="email"
          placeholder="name@company.com"
          value={formData.email}
          onChange={handleChange}
          error={errors.email}
          icon={<MailIcon className="w-5 h-5" />}
          autoComplete="email"
          disabled={isLoading}
        />

        {/* Password Field (Signin and Signup) */}
        {mode !== 'forgot' && (
          <div className="space-y-1">
            <Input
              label="Password"
              id="password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              placeholder={mode === 'signup' ? 'Create a password (min 8 chars)' : '••••••••'}
              value={formData.password}
              onChange={handleChange}
              error={errors.password}
              icon={<LockIcon className="w-5 h-5" />}
              autoComplete={mode === 'signin' ? "current-password" : "new-password"}
              disabled={isLoading}
              rightElement={
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 focus:outline-none"
                  tabIndex={-1}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              }
            />
            {mode === 'signin' && (
              <div className="flex items-center justify-end">
                <button 
                  type="button"
                  onClick={() => switchMode('forgot')}
                  className="text-xs font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 transition-colors"
                >
                  Forgot password?
                </button>
              </div>
            )}
          </div>
        )}

        <Button
          type="submit"
          fullWidth
          isLoading={isLoading}
          variant="primary"
        >
          {mode === 'signin' && 'Sign In'}
          {mode === 'signup' && 'Create Account'}
          {mode === 'forgot' && 'Send Reset Link'}
        </Button>
      </form>

      {/* Mode switching links */}
      {mode === 'forgot' ? (
        <div className="text-center">
           <button 
             onClick={() => switchMode('signin')}
             className="text-sm font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors flex items-center justify-center gap-2 mx-auto"
           >
             <ArrowLeftIcon className="w-4 h-4" /> Back to Sign in
           </button>
        </div>
      ) : (
        <>
          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-800"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white dark:bg-slate-950 text-slate-500 dark:text-slate-400">
                Or continue with
              </span>
            </div>
          </div>

          {/* Social Login Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline" 
              type="button" 
              onClick={() => handleSocialLogin('google')}
              disabled={isLoading}
            >
              <GoogleIcon className="w-5 h-5" />
              <span className="sr-only lg:not-sr-only lg:ml-2">Google</span>
            </Button>
            <Button 
              variant="outline" 
              type="button"
              onClick={() => handleSocialLogin('github')}
              disabled={isLoading}
            >
              <GitHubIcon className="w-5 h-5" />
              <span className="sr-only lg:not-sr-only lg:ml-2">GitHub</span>
            </Button>
          </div>

          <p className="text-center text-sm text-slate-600 dark:text-slate-400">
            {mode === 'signin' ? "Don't have an account? " : "Already have an account? "}
            <button 
              onClick={() => switchMode(mode === 'signin' ? 'signup' : 'signin')}
              className="font-semibold text-primary-600 hover:text-primary-500 dark:text-primary-400 transition-colors"
            >
              {mode === 'signin' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </>
      )}
    </div>
  );
};

export default LoginForm;
