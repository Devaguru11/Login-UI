import { UserCredentials } from '../types';

// Simulate a database delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const STORAGE_KEY = 'lumina_users';
const CURRENT_USER_KEY = 'lumina_current_user';

interface User extends UserCredentials {
  id: string;
  avatar?: string;
  provider?: 'email' | 'google' | 'github';
}

export const authService = {
  // Get all users from local storage
  getUsers: (): User[] => {
    const usersStr = localStorage.getItem(STORAGE_KEY);
    return usersStr ? JSON.parse(usersStr) : [];
  },

  // Save a user to local storage
  saveUser: (user: User) => {
    const users = authService.getUsers();
    users.push(user);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
  },

  // Sign Up
  signup: async (credentials: UserCredentials): Promise<User> => {
    await delay(1200); // Simulate network latency

    const users = authService.getUsers();
    const existingUser = users.find((u) => u.email.toLowerCase() === credentials.email.toLowerCase());

    if (existingUser) {
      throw new Error('An account with this email already exists.');
    }

    const newUser: User = {
      ...credentials,
      id: crypto.randomUUID(),
      provider: 'email',
    };

    authService.saveUser(newUser);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
    return newUser;
  },

  // Sign In
  login: async (credentials: UserCredentials): Promise<User> => {
    await delay(1000); // Simulate network latency

    const users = authService.getUsers();
    const user = users.find((u) => u.email.toLowerCase() === credentials.email.toLowerCase());

    if (!user) {
      throw new Error('Invalid email or password.');
    }

    // In a real app, we would hash passwords. Here we just compare strings.
    if (user.password !== credentials.password && user.provider === 'email') {
      throw new Error('Invalid email or password.');
    }

    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    return user;
  },

  // Social Login Simulation
  socialLogin: async (provider: 'google' | 'github'): Promise<User> => {
    await delay(1500); // Simulate popup and redirection

    // Simulate a successful user from a provider
    const mockUser: User = {
      email: `user@${provider}.com`,
      name: `${provider.charAt(0).toUpperCase() + provider.slice(1)} User`,
      id: crypto.randomUUID(),
      provider: provider,
      avatar: `https://ui-avatars.com/api/?name=${provider}&background=random`
    };

    // Check if we need to "register" this social user or just log them in
    const users = authService.getUsers();
    const existing = users.find(u => u.email === mockUser.email);
    
    if (!existing) {
      authService.saveUser(mockUser);
    }

    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(existing || mockUser));
    return existing || mockUser;
  },

  // Forgot Password
  forgotPassword: async (email: string): Promise<void> => {
    await delay(1000);
    // Just verify format, we don't check existence for security privacy in some flows, 
    // but here we can throw if we want strict feedback.
    if (!email.includes('@')) throw new Error('Invalid email address');
    // Success implies email sent
  },

  // Logout
  logout: () => {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
};
